from string import ascii_letters
from random import *
from programming_language import *
from functional import *
from object_oriented import *
from procedural import *
from container import *
from read_arguments import *