class Language:
    def read_arguments(self, arguments, position):
        pass

    def create_random(self):
        pass

    def write_in_file(self, ostream):
        pass

    def quotient(self):
        pass
