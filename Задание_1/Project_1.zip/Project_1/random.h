#ifndef PROJECT_1_RANDOM_H
#define PROJECT_1_RANDOM_H

#include <stdlib.h>

// Получение случайного числа.
int RandomNumber(int from, int to);

// Получение случайной строки.
void RandomString(char *new_string);

#endif //PROJECT_1_RANDOM_H